package com.makersharks.aditya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdityaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdityaApplication.class, args);
	}

}
